SerialDesk Qt 0.2.0 - Windows x64 preview
=========================================

Extract the ENTIRE ZIP, then double-click SerialDeskQt.exe.
Keep all DLLs and the platforms/styles/sqldrivers directories together.
This is a portable program: no Qt, Node.js or Visual Studio installation is needed.
Target: Windows 11 x64; Windows 10 1809+ compatibility has not been tested.

Included: serial ports, Telnet, tabs/saved sessions, automatic timestamped logs,
complete disk-backed terminal history, and basic macros.
Not yet implemented: Windows local shell (ConPTY), MCP, and automatic reconnect.
Ctrl+C sends an interrupt; Ctrl+Shift+C copies; Ctrl+V pastes.

Workspace/history: use Settings to open the actual application data directory.
Logs: Documents/SerialDesk/Logs by default, configurable in Settings.
No admin rights are needed for the application; USB adapters may require a driver.

Build: cross-compiled on Apple Silicon macOS using official Qt 6.8.3 MinGW
binaries and host tools, MinGW-w64 GCC 13.2.0, and static libvterm 0.3.3.
The PE/DLL dependency and export-symbol audit is included in build-manifest.json.
The EXE has NOT been run on Windows, and Windows startup memory, USB adapters,
hotplug and system IME behavior are NOT verified. This preview is unsigned.

Optional verification on Windows: run tools/run-tests.cmd.
Two POSIX-specific tests are expected to skip on Windows.
If startup fails, keep this entire folder and capture the exact error message.
