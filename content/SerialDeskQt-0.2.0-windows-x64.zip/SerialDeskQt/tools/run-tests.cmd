@echo off
setlocal
cd /d "%~dp0.."
set "PATH=%CD%;%PATH%"
tools\core_tests.exe
if errorlevel 1 exit /b 1
tools\ui_tests.exe
exit /b %errorlevel%
