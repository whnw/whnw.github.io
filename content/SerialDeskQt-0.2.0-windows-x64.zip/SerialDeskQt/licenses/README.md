# Third-party components

This local preview dynamically links Qt 6.11.2 on macOS / Qt 6.8.3 on Windows (Widgets, Gui, Core, Network,
SerialPort, Sql, Core5Compat and deployed plugins), distributed under its
applicable LGPL/GPL/commercial terms. LGPLv3 and GPLv3 texts and the Qt GPL
exception are included here. Qt source and component notices:
https://code.qt.io/ and https://doc.qt.io/qt-6/licenses-used-in-qt.html .

libvterm 0.3.3 is MIT licensed; its copyright and license are included.
Source: https://www.leonerd.org.uk/code/libvterm/ .

The Windows bundle includes GCC 13.2 runtime libraries (GPLv3 with the GCC
Runtime Library Exception), MinGW-w64 and winpthreads. Their additional license
texts are in windows/. GCC source: https://gcc.gnu.org/releases.html ;
MinGW-w64 source: https://github.com/mingw-w64/mingw-w64/tree/v11.0.1 .

Deployment may include Qt's third-party dependencies (e.g. SQLite, HarfBuzz,
Brotli, zstd, PCRE2 and double-conversion). A complete per-binary SBOM and all
applicable third-party notices must be assembled before public distribution.
This preview has not been prepared as a public distribution release.
