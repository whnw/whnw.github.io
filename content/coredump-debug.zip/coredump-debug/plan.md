A previous agent produced the plan below to accomplish the user's task. Implement
  the plan in a fresh context. Treat the plan as the source of user intent, re-read
  files as needed, and carry the work through implementation and verification.

  # curl/OpenSSL Core Dump 复现与修复

  ## Summary

  在当前 macOS arm64 环境中，使用官方源码构建 OpenSSL 3.5.7 和 curl 8.20.0，补全
  README 中的两个 C 函数及最小 `main`，先运行原始逻辑复现，再依据调试证据做最小修
  复。依赖版本和源码分别以 [OpenSSL 官方发布](https://www.openssl-library.org/
  source/) 与 [curl 官方归档](https://curl.se/download/) 为准。

  ## Implementation Changes

  - 新建 `networkUtils.c`，补齐常量、返回值、HTTPS 判断、User-Agent、header/file
  callbacks、文件大小查询、下载及资源释放；保留原始 TLS 配置作为复现基线。
  - 新建最小 `main`：执行 `curl_global_init()`，调用 `curlDownloadFile()` 下载
  README 中的 URL 到工作区临时文件，打印 libcurl/SSL 后端版本、返回值和文件大小。
  - 提供可重复构建脚本或 Makefile：
    - 下载并校验 OpenSSL 3.5.7、curl 8.20.0 官方源码。
    - 构建静态调试版本，禁用无关 curl 协议和第三方库，确保样例不会误链接本机
  OpenSSL 3.6.2 或系统 SecureTransport。
    - 使用 `/etc/ssl/cert.pem` 验证服务器证书。
  - 先用未修复版本循环执行，并通过 LLDB、AddressSanitizer/
  UndefinedBehaviorSanitizer收集崩溃点；对比 TLS 1.3 与“最低和最高均为 TLS 1.2”的控
  制组。注意原代码的 `CURL_SSLVERSION_TLSv1_2` 只是最低版本，仍会协商 TLS 1.3。
  - 根据证据在最早出错层做最小修复：
    - 修正所有未保存 `curl_easy_setopt()` 返回值却检查旧 `res` 的调用。
    - 使用符合 libcurl ABI 的 `size_t callback(char *, size_t, size_t, void *)`。
    - HEAD 完成后正确恢复 `CURLOPT_NOBODY`、`CURLOPT_HEADER` 和 header callback，再
  执行文件下载。
    - 使用 `CURLINFO_CONTENT_LENGTH_DOWNLOAD_T`/`curl_off_t`，转换到 `int` 前检查溢
  出。
    - 保证文件、easy handle 和全局 curl 状态在所有错误路径正确释放。
    - 若干净构建仍确认是 OpenSSL TLS 1.3 ticket 路径缺陷，则保留证据并采用精确 TLS
  1.2 上限作为可验证的应用层规避；不在无证据时修改 OpenSSL 内部源码或宣称其为根因。
  - 更新 README，记录构建命令、实际复现结果、诊断证据、修复差异及执行方法。

  ## Test Plan

  - 校验运行时明确报告 `libcurl/8.20.0 OpenSSL/3.5.7`。
  - 原始版本正常构建，并连续运行至少 20 次；记录是否稳定复现及 LLDB/ASan 回溯。
  - TLS 1.3 和严格 TLS 1.2 各运行至少 20 次，用于确认 session-ticket 路径相关性。
  - 修复版本连续运行至少 20 次，无崩溃、无 sanitizer 报告。
  - 验证 HTTP 状态为 200、下载文件非空、`pFileSize` 与磁盘文件大小一致。
  - 验证不可达 URL、证书校验失败和不可写输出路径均返回错误且不泄漏资源。

  ## Assumptions

  - 主要验收平台为当前 macOS arm64；不搭建 Linux musl/aarch64 虚拟环境。
  - 若本机无法复现，将明确记录“未复现”，提交已验证的代码修复、诊断能力和 TLS 控制组
  结果，不把现场回溯仅凭调用栈归因于 OpenSSL。
  - 下载源码和编译产物放在工作区的依赖/构建目录，不安装或覆盖系统库。
