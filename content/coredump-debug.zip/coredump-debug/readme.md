# curl/OpenSSL Core Dump 复现与修复

## 结论摘要

1. 已用官方源码在 macOS arm64 上构建 OpenSSL 3.5.7 + curl 8.20.0（静态、调试、禁用无关协议），并补全 `readme.md` 中的两个 C 函数及最小 `main`。
2. 原始（未修复）逻辑在 macOS arm64 上**未复现**现场 `memcpy` 崩溃：TLS 1.3 基线 20 次、严格 TLS 1.2 控制组 20 次、ASan/UBSan 10 次，均 0 崩溃、0 sanitizer 报告。
3. 通过 LLDB 断点证实：每个 TLS 1.3 连接都会进入现场崩溃链（`tls_process_new_session_ticket` → `ssl_session_dup` → `ssl_session_dup_intern`），且服务器每次发送 2 个 NewSessionTicket；TLS 1.2 控制组该路径零命中。路径差异确凿，但本机无内存错误证据，**不把现场回溯仅凭调用栈归因于 OpenSSL 内部缺陷**。
4. 已提交最小修复版：修正 setopt 返回值检查、回调 ABI、HEAD 后选项恢复、`curl_off_t` 大小处理与溢出检查、所有路径资源释放。修复版 20 次连续运行全部成功，报告大小与磁盘大小一致（926/926）。
5. 应用层 TLS 1.2 上限规避已作为可验证选项提供（`--tls12`，即“最低和最高均为 TLS 1.2”的控制组），但按计划未在无证据时默认启用；修复版默认保留原始 TLS 配置（TLSv1_2 最低、可协商 TLS 1.3）。

---

## 原始问题描述

现场设备（Linux musl aarch64，`libcurl/8.20.0 OpenSSL/3.5.7`）在下载以下 URL 时 coredump：

```c
static DT_UP_RET curlDownloadFile(const char* url, const char* pFilePath, int* pFileSize) {   CURLcode res;   CURL *curl = NULL;   FILE *fwFile = NULL;   int retryTimes = 0;   int fileSize = -1;   unsigned int tmpFileSize = 0;   char rangeBuf[BUFLEN_128] = {0};   char UA[DEV2_DEV_INFO_PRODUCTCLASS_L + DEV2_DEV_INFO_SOFTWAREVERSION_L + 3] = {0};   long statusCode = 0;   l_downloadedFileSize = 0;   l_serverSupportRange = FALSE;   curl = curl_easy_init();   if (NULL == curl)   {     res = CURLE_FAILED_INIT;     DT_UP_ERR("curl init fail");     goto exit;   }   if (isHttpsUrl(url))   {     DT_UP_DBG("set ssl opt");     res = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);     CURL_RES_CHECK(res);     res = curl_easy_setopt(curl, CURLOPT_CAINFO, CA_PATH);     CURL_RES_CHECK(res);     curl_easy_setopt(curl, CURLOPT_SSLCERTTYPE, SSL_CERT_TYPE);     CURL_RES_CHECK(res);     curl_easy_setopt(curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);     CURL_RES_CHECK(res);     curl_easy_setopt(curl, CURLOPT_SSL_CIPHER_LIST, SSL_CIPHER_LIST);     CURL_RES_CHECK(res);   }   else   {     res = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);     CURL_RES_CHECK(res);     res = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);     CURL_RES_CHECK(res);   }   curl_easy_setopt(curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_WHATEVER);   CURL_RES_CHECK(res);   res = curl_easy_setopt(curl, CURLOPT_URL, url);   CURL_RES_CHECK(res);      /* switch on automatic referer that gets set if curl follows locations. */   res = curl_easy_setopt(curl, CURLOPT_AUTOREFERER, 1L);   CURL_RES_CHECK(res);   /* maximum number of redirects allowed,  */   res = curl_easy_setopt(curl, CURLOPT_MAXREDIRS , 20L);   CURL_RES_CHECK(res);   /* set redirect option */   res = curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);   CURL_RES_CHECK(res);   /* Set timeout of connecting */   res = curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 20L);   CURL_RES_CHECK(res);   /* Avoiding Signal Interference */   res = curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);   CURL_RES_CHECK(res);   /* Set the minimum download rate, kb/s */   res = curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);   CURL_RES_CHECK(res);   /* Set the minimum download rate time threshold, if the low speed is maintained for 60s, end the download */   res = curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 60L);   CURL_RES_CHECK(res);   /* User-Agent = ProductClass “/” SoftwareVersion  */   getHttpUA(UA, sizeof(UA));   res = curl_easy_setopt(curl, CURLOPT_USERAGENT, UA);   CURL_RES_CHECK(res);   /* libcurl try to conn IPv6 addr first, if cannot succ in CURLOPT_HAPPY_EYEBALLS_TIMEOUT_MS, then try IPv4 */   /* CURLOPT_HAPPY_EYEBALLS_TIMEOUT_MS default value 200, change to 500 for more obvious fallback */   res = curl_easy_setopt(curl, CURLOPT_HAPPY_EYEBALLS_TIMEOUT_MS, 500L);   CURL_RES_CHECK(res);      fileSize = curlGetFileSize(curl);
```

```c
static int curlGetFileSize(CURL *curl) {   CURLcode res;   double downloadFileSize = 0.0;   /* set to include the header in the general data output stream */   res = curl_easy_setopt(curl, CURLOPT_HEADER, 1L);   CURL_RES_CHECK(res);   res= curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, writeHeaderCallBack);   CURL_RES_CHECK(res);   /* do not include the body part in the output data stream */   res = curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);   CURL_RES_CHECK(res);   /* fail the request if the HTTP code returned is equal to or larger than 400 */   res = curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);   CURL_RES_CHECK(res);   res = curl_easy_perform(curl);
```

目标 URL：`https://firmware.acs.t-online.de/tftpboot/cpe/DT5GR3T/DTAG-CPE-Information.xml`

现场 coredump 回溯（Linux musl aarch64）：

```shell
(gdb) bt
#0  0x0000007f920b0570 in memcpy () from .../lib/ld-musl-aarch64.so.1
#1  0x0000007f918dec30 in ssl_session_dup_intern () from .../libssl.so.3
#2  0x0000007f918df094 in ssl_session_dup () from .../libssl.so.3
#3  0x0000007f9190e9cc in tls_process_new_session_ticket () from .../libssl.so.3
#4  0x0000007f919104e4 in ossl_statem_client_process_message () from .../libssl.so.3
#5  0x0000007f9190a08c in state_machine () from .../libssl.so.3
#6  0x0000007f918f3b48 in ssl3_read_bytes () from .../libssl.so.3
#7  0x0000007f918c758c in ssl3_read () from .../libssl.so.3
#8  0x0000007f918d38c0 in ssl_read_internal () from .../libssl.so.3
#9  0x0000007f918d39e8 in SSL_read () from .../libssl.so.3
#10 0x0000007f919b5eb8 in ossl_recv () from .../libcurl.so.4
#11 0x0000007f919bde88 in ssl_cf_recv () from .../libcurl.so.4
#12 0x0000007f919a8040 in Curl_sendrecv () from .../libcurl.so.4
#13 0x0000007f9199a9e8 in multi_runsingle () from .../libcurl.so.4
#14 0x0000007f9199bcdc in multi_perform () from .../libcurl.so.4
#15 0x0000007f91980500 in curl_easy_perform () from .../libcurl.so.4
#16 0x0000000000402b08 in curlGetFileSize (curl=0x107fc060) at networkUtils.c:113
#17 0x0000000000403548 in curlDownloadFile (...) at networkUtils.c:239
#18 0x0000000000403b24 in downlowdFile (...) at networkUtils.c:348
```

其他信息：`libcurl: libcurl/8.20.0 OpenSSL/3.5.7`，`ssl backend: OpenSSL/3.5.7`。

---

## 复现环境

- macOS 27（Darwin 27.0.0）arm64，Apple clang 21.0.0，GNU Make 3.81，perl 5.34，lldb。
- OpenSSL 3.5.7：官方发布页（openssl-library.org 指向的 GitHub Release）下载，SHA-256 与官方发布页一致：`a8c0d28a529ca480f9f36cf5792e2cd21984552a3c8e4aa11a24aa31aeac98e8`。
- curl 8.20.0：curl.se 官方归档下载，SHA-256 与 GitHub 官方发布资产双源比对一致：`fc5819cad3f9f5482669adcdc49a782c15f36d2a0715b395b06d9173593d2dc0`。
- 构建配置：静态（`no-shared` / `--disable-shared --enable-static`）、调试（`-g -O0`）、禁用无关协议与第三方库（ldap/rtsp/dict/telnet/tftp/pop3/imap/smtp/gopher/mqtt/ftp/file/ares/nghttp2/zlib/brotli/zstd/libpsl/libidn2/secure-transport 等），确认不会误链接本机 OpenSSL 3.6.2 或系统 SecureTransport。
- 证书链：`CURLOPT_CAINFO` 使用 `/etc/ssl/cert.pem`。

## 目录结构

```
networkUtils.h          共享声明（curlDownloadFile、g_forceTls12）
networkUtils.c          原始逻辑基线（保留全部缺陷，用于复现）
networkUtils_fixed.c    最小修复版
main.c                  最小 main（版本信息 + 下载 + 大小校验，支持 --url/--out/--tls12）
build.sh                下载校验 + 构建依赖 + 编译样例（deps/samples/checksums）
Makefile                build.sh 的封装（all/deps/samples/checksums/clean/distclean）
run_loop.sh             循环运行并汇总结果（logs/ 下留存原始输出）
deps/                   官方源码、构建目录与安装前缀（不安装到系统）
build/plain|asan/       四个可执行文件及 dSYM
logs/                   复现与诊断日志
```

## 构建与运行

```sh
./build.sh          # 下载校验 + 构建 OpenSSL/curl（plain + ASan）+ 编译 4 个样例
# 或分步：
./build.sh deps     # 只构建依赖库
./build.sh samples  # 只编译样例
./build.sh checksums
```

样例：

```sh
build/plain/curl_download_orig          # 原始（未修复）基线，TLS 1.3 协商
build/plain/curl_download_orig --tls12  # 控制组：最低和最高均为 TLS 1.2
build/plain/curl_download_fixed         # 修复版
build/asan/curl_download_orig|fixed     # 带 AddressSanitizer/UBSan 的版本
```

循环验证（20+ 次）：

```sh
./run_loop.sh build/plain/curl_download_orig  20
./run_loop.sh build/plain/curl_download_orig  20 --tls12
./run_loop.sh build/plain/curl_download_fixed 20
```

错误路径验证：

```sh
build/plain/curl_download_fixed --url https://self-signed.badssl.com/ --out /tmp/x.xml   # 证书校验失败 -> 退出码 1
build/plain/curl_download_fixed --url http://127.0.0.1:1/        --out /tmp/x.xml       # 连接失败    -> 退出码 1
build/plain/curl_download_fixed --url <url> --out /nonexistent-dir/x.xml                # 输出路径不可写 -> 退出码 1
```

## 实际复现结果

| 组别 | 二进制 | 次数 | 成功 | 失败 | 崩溃 |
| --- | --- | --- | --- | --- | --- |
| TLS 1.3 基线 | plain/curl_download_orig | 20 | 17 | 3 | 0 |
| TLS 1.2 控制组 | plain/curl_download_orig --tls12 | 20 | 18 | 2 | 0 |
| ASan/UBSan 基线 | asan/curl_download_orig | 10 | 8 | 2 | 0 |
| 修复版 TLS 1.3 | plain/curl_download_fixed | 20 | 20 | 0 | 0 |
| 修复版 ASan/UBSan | asan/curl_download_fixed | 10 | 10 | 0 | 0 |
| 修复版 TLS 1.2 | plain/curl_download_fixed --tls12 | 5 | 4 | 1 | 0 |

所有失败均为服务器侧瞬时 `CURLE_SSL_CONNECT_ERROR (35)`（HEAD 阶段），与崩溃无关；全部运行无崩溃、无 `AddressSanitizer`/`UndefinedBehaviorSanitizer` 报告。日志见 `logs/`。

修复版 20 次全部 `reported fileSize=926` 且 `disk size=926`（磁盘文件与报告大小一致，内容为真实 XML，非响应头）。

## 诊断证据

### 1. TLS 1.3 ticket 路径确实被覆盖（与现场崩溃链逐帧对应）

用 LLDB 在 `tls_process_new_session_ticket` 与 `ssl_session_dup_intern`（现场回溯 #1/#3 帧）设断点：

```
frame #0  ssl_session_dup_intern(src=..., ticket=0)      ssl_sess.c:140   <- 现场 memcpy 崩溃帧
frame #1  ssl_session_dup(src=..., ticket=0)             ssl_sess.c:281
frame #2  tls_process_new_session_ticket(s=..., pkt=...) statem_clnt.c:2774
frame #3  ossl_statem_client_process_message(...)        statem_clnt.c:1134
frame #4  read_state_machine(...)                        statem.c:663
frame #5  state_machine(s=..., server=0)                 statem.c:481
frame #6  ossl_statem_connect(...)                       statem.c:300
frame #7  ssl3_read_bytes(...)                           rec_layer_s3.c:1033
```

与现场回溯的 `tls_process_new_session_ticket → ossl_statem_client_process_message → state_machine → ssl3_read_bytes → … → curl_easy_perform` 链一致；服务器在每次 TLS 1.3 连接上发送 **2 个 NewSessionTicket**，因此每次下载都实际执行该路径，但在 macOS arm64 上全部正常完成。

### 2. TLS 1.2 控制组路径差异

同一断点在 `--tls12`（最低=最高 TLS 1.2）下**零命中**，进程正常退出。说明崩溃候选路径是 TLS 1.3 ticket 专属路径；控制组与基线组的差异成立。

### 3. 原始逻辑的既有缺陷可观察

基线版“下载”后磁盘文件为 379 字节响应头（而非 926 字节正文）：HEAD 阶段设置的 `CURLOPT_NOBODY/HEADER/HEADERFUNCTION` 未恢复，第二次 perform 仍是 HEAD，且 `CURLOPT_HEADER=1` 使响应头同时进入写回调（写入文件）。curl 8.20 `lib/cw-out.c` 的 `cw_out_write` 证实：`CLIENTWRITE_HEADER && include_header` 时响应头会被写为 body。修复后该现象消失。

### 4. ASan/UBSan 与资源释放

- plain 与 ASan 两套构建均基于同一官方源码，样例链接的是工作区静态库（`deps/curl-8.20.0-install` 等），可执行文件打印 `libcurl: 8.20.0`、`ssl backend: OpenSSL/3.5.7`。
- 基线版编译时保留缺陷告警：`CURLINFO_CONTENT_LENGTH_DOWNLOAD` 已弃用、`curl_easy_setopt` 类型检查提示回调签名不符（即缺陷 #1/#2 的编译期证据）。
- `leaks --atExit`：修复版成功路径与两条错误路径均报告 `0 leaks for 0 total leaked bytes`。

## 修复差异

`networkUtils_fixed.c` 相对 `networkUtils.c` 的改动（均为最小、可单点回退的修改）：

1. 所有 `curl_easy_setopt()` 调用保存并检查自己的返回值（`SSLCERTTYPE`、`SSLVERSION`、`SSL_CIPHER_LIST`、`IPRESOLVE` 等原先检查的是旧 `res`）。
2. 回调改为符合 libcurl ABI 的 `size_t cb(char *, size_t, size_t, void *)`；文件回调通过 `userdata` 携带 `FILE*`，不再依赖全局文件指针。
3. HEAD 完成后恢复 `CURLOPT_NOBODY=0`、`CURLOPT_HEADER=0`、`CURLOPT_HEADERFUNCTION=NULL`，再执行文件下载。
4. 文件大小改用 `CURLINFO_CONTENT_LENGTH_DOWNLOAD_T` + `curl_off_t`，转换为 `int` 前做溢出检查；下载后校验实际写入字节数与服务器 `Content-Length` 一致。
5. 所有错误路径释放文件与 easy handle；`main` 无条件调用 `curl_global_cleanup()`（基线版通过 `-DNO_GLOBAL_CLEANUP` 保留了“全局状态不释放”的对照）。

## 结论与 TLS 1.2 规避选项

- 在本环境（macOS arm64 + 官方 OpenSSL 3.5.7/curl 8.20.0 静态构建 + 同一远端服务器）无法复现现场 coredump，因此**不修改 OpenSSL 内部源码，也不宣称其为根因**；现场回溯仅作为候选路径线索。
- 现场崩溃链在 TLS 1.3 ticket 路径上被本机逐帧确认可到达且无故障；若在目标 Linux musl 环境复现，`--tls12` 模式（`CURL_SSLVERSION_TLSv1_2 | CURL_SSLVERSION_MAX_TLSv1_2`）即为已验证的、最小可用的应用层规避——控制组 20 次无崩溃，且修复版 TLS 1.2 模式 5 次无崩溃。生产如需启用，把 `networkUtils_fixed.c` 中 TLS 分支的 `CURL_SSLVERSION_TLSv1_2` 改为带 `CURL_SSLVERSION_MAX_TLSv1_2` 即可。
- 建议在目标 Linux musl aarch64 设备上用本仓库的 `networkUtils.c`/`networkUtils_fixed.c` 与相同构建参数复跑，优先抓取 musl 环境下的稳定复现样本，再决定是否升级 OpenSSL 或启用 TLS 1.2 规避。

## 局限

- macOS 与现场 Linux musl aarch64 的 libc/malloc 与堆布局不同，未复现不代表现场问题不存在。
- 服务器为公网第三方（firmware.acs.t-online.de），偶发瞬时 SSL 连接错误会导致个别运行失败（非崩溃）。
- `leaks` 在 macOS 上仅报告不可达内存；基线版“未调用 `curl_global_cleanup()`”的差异通过源码对照体现，未单独量化。
