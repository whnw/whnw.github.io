/*
 * networkUtils_fixed.c - minimal fix on top of the baseline in networkUtils.c.
 *
 * Fixes applied (each maps to a defect listed at the top of networkUtils.c):
 *
 *  1. every curl_easy_setopt() return value is captured and checked;
 *  2. header/file callbacks use the libcurl ABI signature
 *     size_t cb(char *, size_t, size_t, void *);
 *  3. after the HEAD request CURLOPT_NOBODY, CURLOPT_HEADER and
 *     CURLOPT_HEADERFUNCTION are restored before the file download;
 *  4. CURLINFO_CONTENT_LENGTH_DOWNLOAD_T + curl_off_t with an overflow check
 *     before converting to int;
 *  5. file, easy handle and global curl state are released on every path
 *     (curl_global_cleanup() is unconditional in main.c).
 *
 * The TLS configuration intentionally stays the original baseline
 * (TLSv1_2 minimum, TLS 1.3 negotiated); --tls12 pins the control group to
 * TLS 1.2.  No OpenSSL internals are modified.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <curl/curl.h>

#include "networkUtils.h"

#define BUFLEN_128 128

#define CA_PATH         "/etc/ssl/cert.pem"
#define SSL_CERT_TYPE   "PEM"
#define SSL_CIPHER_LIST "DEFAULT"

#define DEV2_DEV_INFO_PRODUCTCLASS_L   32
#define DEV2_DEV_INFO_SOFTWAREVERSION_L 16
#define DEV2_PRODUCT_CLASS   "DT5GR3T"
#define DEV2_SOFTWARE_VERSION "1.0.0"

#define DOWNLOAD_RETRY_TIMES 3
#define HTTP_STATUS_OK 200
#define HTTP_STATUS_PARTIAL_CONTENT 206

#define TRUE  1
#define FALSE 0

#define DT_UP_ERR(...) do { fprintf(stderr, "[ERR] " __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#define DT_UP_DBG(...) do { printf("[DBG] " __VA_ARGS__); printf("\n"); } while (0)

#define CURL_RES_CHECK(res) do {                                                \
        if ((res) != CURLE_OK) {                                                \
            DT_UP_ERR("curl error %d (%s) at %s:%d",                            \
                      (res), curl_easy_strerror(res), __FILE__, __LINE__);      \
            goto exit;                                                          \
        }                                                                       \
    } while (0)

/* bytes written to the output file / server-reported Content-Length / whether
 * the server accepts byte ranges.  State is file-scope so the callbacks and
 * curlDownloadFile() share it without extending the ABI callback contract. */
static curl_off_t l_downloadedFileSize = 0;
static curl_off_t l_serverFileSize = 0;
static int l_serverSupportRange = FALSE;

static const char *ciFind(const char *haystack, const char *needle)
{
    size_t nlen = strlen(needle);

    if (nlen == 0)
    {
        return haystack;
    }
    for (; *haystack != '\0'; haystack++)
    {
        if (strncasecmp(haystack, needle, nlen) == 0)
        {
            return haystack;
        }
    }
    return NULL;
}

static int isHttpsUrl(const char *url)
{
    return (NULL != url) && (strncasecmp(url, "https://", 8) == 0);
}

static void getHttpUA(char *ua, size_t len)
{
    snprintf(ua, len, "%s/%s", DEV2_PRODUCT_CLASS, DEV2_SOFTWARE_VERSION);
}

/* FIX (2): libcurl ABI signature. */
static size_t writeHeaderCallBack(char *buffer, size_t size, size_t nitems, void *userdata)
{
    const char *p = NULL;

    (void)userdata;
    if ((p = ciFind(buffer, "Content-Length:")) != NULL)
    {
        l_serverFileSize = (curl_off_t)atoll(p + strlen("Content-Length:"));
    }
    else if ((p = ciFind(buffer, "Accept-Ranges:")) != NULL &&
             ciFind(p, "bytes") != NULL)
    {
        l_serverSupportRange = TRUE;
    }
    return size * nitems;
}

/* FIX (2): libcurl ABI signature; userdata carries the FILE*. */
static size_t writeFileCallBack(char *buffer, size_t size, size_t nitems, void *userdata)
{
    FILE *fp = (FILE *)userdata;
    size_t written = 0;

    if (NULL != fp)
    {
        written = fwrite(buffer, size, nitems, fp);
        l_downloadedFileSize += (curl_off_t)(size * written);
    }
    return size * written;
}

static int curlGetFileSize(CURL *curl)
{
    CURLcode res;
    curl_off_t downloadFileSize = -1; /* FIX (4) */

    /* set to include the header in the general data output stream */
    res = curl_easy_setopt(curl, CURLOPT_HEADER, 1L);
    CURL_RES_CHECK(res);

    res = curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, writeHeaderCallBack);
    CURL_RES_CHECK(res);

    /* do not include the body part in the output data stream */
    res = curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    CURL_RES_CHECK(res);

    /* fail the request if the HTTP code returned is equal to or larger than 400 */
    res = curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
    CURL_RES_CHECK(res);

    res = curl_easy_perform(curl);
    CURL_RES_CHECK(res);

    res = curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD_T, &downloadFileSize);
    CURL_RES_CHECK(res);

    /* FIX (4): overflow check before the double->int style conversion */
    if (downloadFileSize < 0 || downloadFileSize > INT_MAX)
    {
        DT_UP_ERR("file size out of int range: %lld", (long long)downloadFileSize);
        res = CURLE_FILESIZE_EXCEEDED;
        goto exit;
    }

    /* FIX (3): restore every option changed for the HEAD request */
    res = curl_easy_setopt(curl, CURLOPT_NOBODY, 0L);
    CURL_RES_CHECK(res);
    res = curl_easy_setopt(curl, CURLOPT_HEADER, 0L);
    CURL_RES_CHECK(res);
    res = curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, NULL);
    CURL_RES_CHECK(res);

    return (int)downloadFileSize;

exit:
    return -1;
}

DT_UP_RET curlDownloadFile(const char *url, const char *pFilePath, int *pFileSize)
{
    CURLcode res;
    CURL *curl = NULL;
    FILE *fwFile = NULL;
    int retryTimes = 0;
    int fileSize = -1;
    unsigned int tmpFileSize = 0;
    char rangeBuf[BUFLEN_128] = {0};
    char UA[DEV2_DEV_INFO_PRODUCTCLASS_L + DEV2_DEV_INFO_SOFTWAREVERSION_L + 3] = {0};
    long statusCode = 0;

    l_downloadedFileSize = 0;
    l_serverFileSize = 0;
    l_serverSupportRange = FALSE;

    curl = curl_easy_init();
    if (NULL == curl)
    {
        res = CURLE_FAILED_INIT;
        DT_UP_ERR("curl init fail");
        goto exit;
    }

    if (isHttpsUrl(url))
    {
        DT_UP_DBG("set ssl opt");
        res = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        CURL_RES_CHECK(res);

        res = curl_easy_setopt(curl, CURLOPT_CAINFO, CA_PATH);
        CURL_RES_CHECK(res);

        /* FIX (1): every setopt return value is captured and checked. */
        res = curl_easy_setopt(curl, CURLOPT_SSLCERTTYPE, SSL_CERT_TYPE);
        CURL_RES_CHECK(res);

        if (g_forceTls12)
        {
            /* diagnostic control group: min and max are both TLS 1.2 */
            res = curl_easy_setopt(curl, CURLOPT_SSLVERSION,
                                   CURL_SSLVERSION_TLSv1_2 | CURL_SSLVERSION_MAX_TLSv1_2);
            CURL_RES_CHECK(res);
        }
        else
        {
            /* original baseline: TLSv1_2 is only the minimum; TLS 1.3 is
             * still negotiated. */
            res = curl_easy_setopt(curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
            CURL_RES_CHECK(res);
        }

        res = curl_easy_setopt(curl, CURLOPT_SSL_CIPHER_LIST, SSL_CIPHER_LIST);
        CURL_RES_CHECK(res);
    }
    else
    {
        res = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        CURL_RES_CHECK(res);
        res = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        CURL_RES_CHECK(res);
    }

    res = curl_easy_setopt(curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_WHATEVER);
    CURL_RES_CHECK(res);

    res = curl_easy_setopt(curl, CURLOPT_URL, url);
    CURL_RES_CHECK(res);

    /* switch on automatic referer that gets set if curl follows locations. */
    res = curl_easy_setopt(curl, CURLOPT_AUTOREFERER, 1L);
    CURL_RES_CHECK(res);

    /* maximum number of redirects allowed */
    res = curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 20L);
    CURL_RES_CHECK(res);

    /* set redirect option */
    res = curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    CURL_RES_CHECK(res);

    /* Set timeout of connecting */
    res = curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 20L);
    CURL_RES_CHECK(res);

    /* Avoiding Signal Interference */
    res = curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    CURL_RES_CHECK(res);

    /* Set the minimum download rate, kb/s */
    res = curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    CURL_RES_CHECK(res);

    /* Set the minimum download rate time threshold, if the low speed is
     * maintained for 60s, end the download */
    res = curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 60L);
    CURL_RES_CHECK(res);

    /* User-Agent = ProductClass "/" SoftwareVersion */
    getHttpUA(UA, sizeof(UA));
    res = curl_easy_setopt(curl, CURLOPT_USERAGENT, UA);
    CURL_RES_CHECK(res);

    res = curl_easy_setopt(curl, CURLOPT_HAPPY_EYEBALLS_TIMEOUT_MS, 500L);
    CURL_RES_CHECK(res);

    fileSize = curlGetFileSize(curl);
    if (fileSize <= 0)
    {
        DT_UP_ERR("get file size fail %d", fileSize);
        res = CURLE_PARTIAL_FILE;
        goto exit;
    }

    fwFile = fopen(pFilePath, "wb");
    if (NULL == fwFile)
    {
        DT_UP_ERR("open file fail %s", pFilePath);
        res = CURLE_WRITE_ERROR;
        goto exit;
    }

    res = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeFileCallBack);
    CURL_RES_CHECK(res);
    res = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)fwFile);
    CURL_RES_CHECK(res);

    for (retryTimes = 0; retryTimes < DOWNLOAD_RETRY_TIMES; retryTimes++)
    {
        if (TRUE == l_serverSupportRange && l_downloadedFileSize > 0)
        {
            /* resume from the bytes already written */
            snprintf(rangeBuf, sizeof(rangeBuf), "%lld-",
                     (long long)l_downloadedFileSize);
            res = curl_easy_setopt(curl, CURLOPT_RANGE, rangeBuf);
            CURL_RES_CHECK(res);
        }
        else
        {
            res = curl_easy_setopt(curl, CURLOPT_RANGE, NULL);
            CURL_RES_CHECK(res);
        }

        res = curl_easy_perform(curl);
        if (res != CURLE_OK)
        {
            DT_UP_ERR("download perform fail: %s", curl_easy_strerror(res));
            continue;
        }

        res = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &statusCode);
        CURL_RES_CHECK(res);
        if (statusCode != HTTP_STATUS_OK && statusCode != HTTP_STATUS_PARTIAL_CONTENT)
        {
            DT_UP_ERR("download http status fail: %ld", statusCode);
            res = CURLE_HTTP_RETURNED_ERROR;
            continue;
        }
        break;
    }

    if (retryTimes >= DOWNLOAD_RETRY_TIMES)
    {
        DT_UP_ERR("download retry exhausted");
        res = CURLE_PARTIAL_FILE;
        goto exit;
    }

    /* FIX (4): verify the bytes actually written match the server size and
     * fit into the int out-parameter. */
    if (l_serverFileSize > 0 && l_downloadedFileSize != l_serverFileSize)
    {
        DT_UP_ERR("size mismatch: downloaded %lld vs server %lld",
                  (long long)l_downloadedFileSize, (long long)l_serverFileSize);
        res = CURLE_PARTIAL_FILE;
        goto exit;
    }
    if (l_downloadedFileSize < 0 || l_downloadedFileSize > INT_MAX)
    {
        DT_UP_ERR("downloaded size out of int range: %lld",
                  (long long)l_downloadedFileSize);
        res = CURLE_FILESIZE_EXCEEDED;
        goto exit;
    }

    tmpFileSize = (unsigned int)l_downloadedFileSize;
    if (NULL != pFileSize)
    {
        *pFileSize = (int)tmpFileSize;
    }
    res = CURLE_OK;

exit:
    if (NULL != fwFile)
    {
        fclose(fwFile);
        fwFile = NULL;
    }
    if (NULL != curl)
    {
        curl_easy_cleanup(curl);
        curl = NULL;
    }
    return (CURLE_OK == res) ? DT_UP_RET_OK : DT_UP_RET_FAIL;
}
