/*
 * Minimal main() for the curl/OpenSSL coredump reproduction.
 *
 * Downloads the URL from readme.md into a temp file, prints the libcurl/SSL
 * backend versions, the return value and the file size.  Options:
 *   --tls12        diagnostic control group (TLS 1.2 minimum and maximum)
 *   --url <url>    override the download URL
 *   --out <path>   override the output file path
 *
 * Build with -DNO_GLOBAL_CLEANUP for the "original" baseline (global curl
 * state is never released); the fixed build always calls curl_global_cleanup().
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include <curl/curl.h>

#include "networkUtils.h"

int g_forceTls12 = 0;

#define DEFAULT_URL  "https://firmware.acs.t-online.de/tftpboot/cpe/DT5GR3T/DTAG-CPE-Information.xml"
#define DEFAULT_OUT  "/tmp/DTAG-CPE-Information.xml"

int main(int argc, char *argv[])
{
    CURLcode gres;
    curl_version_info_data *vinfo = NULL;
    const char *url = DEFAULT_URL;
    const char *outPath = DEFAULT_OUT;
    int fileSize = -1;
    int rc = 1;
    struct stat st;
    int i;

    for (i = 1; i < argc; i++)
    {
        if (0 == strcmp(argv[i], "--tls12"))
        {
            g_forceTls12 = 1;
        }
        else if (0 == strcmp(argv[i], "--url") && i + 1 < argc)
        {
            url = argv[++i];
        }
        else if (0 == strcmp(argv[i], "--out") && i + 1 < argc)
        {
            outPath = argv[++i];
        }
        else
        {
            fprintf(stderr, "usage: %s [--tls12] [--url <url>] [--out <path>]\n",
                    argv[0]);
            return 2;
        }
    }

    gres = curl_global_init(CURL_GLOBAL_DEFAULT);
    if (gres != CURLE_OK)
    {
        fprintf(stderr, "[ERR] curl_global_init failed: %d (%s)\n",
                gres, curl_easy_strerror(gres));
        return 2;
    }

    vinfo = curl_version_info(CURLVERSION_NOW);
    if (NULL != vinfo)
    {
        printf("libcurl: %s\n", vinfo->version);
        printf("ssl backend: %s\n",
               (vinfo->ssl_version != NULL) ? vinfo->ssl_version : "(none)");
    }
    printf("tls mode: %s\n",
           g_forceTls12 ? "TLS 1.2 only (min=max)" : "TLS 1.3 negotiated (baseline)");
    printf("url: %s\n", url);
    printf("out: %s\n", outPath);
    fflush(stdout);

    if (DT_UP_RET_OK == curlDownloadFile(url, outPath, &fileSize))
    {
        printf("download ok, reported fileSize=%d\n", fileSize);
        rc = 0;
    }
    else
    {
        fprintf(stderr, "[ERR] curlDownloadFile failed\n");
        rc = 1;
    }

    if (0 == stat(outPath, &st))
    {
        printf("disk size: %lld\n", (long long)st.st_size);
    }
    else
    {
        printf("disk size: stat failed (%s)\n", strerror(errno));
    }
    fflush(stdout);

#ifndef NO_GLOBAL_CLEANUP
    curl_global_cleanup();
#endif
    return rc;
}
