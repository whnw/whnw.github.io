#ifndef NETWORKUTILS_H
#define NETWORKUTILS_H

/* Shared declarations between main.c and the two networkUtils variants.
 *
 * - networkUtils.c          : "original" baseline, keeps the defects from the
 *                             field code so the crash path can be reproduced.
 * - networkUtils_fixed.c    : minimal fix, same flow with corrected error
 *                             handling, callbacks, HEAD-state restore and
 *                             size handling.
 */

#define DT_UP_RET_OK   0
#define DT_UP_RET_FAIL (-1)

typedef int DT_UP_RET;

/* Diagnostic switch, set from main() with --tls12.
 * 0 = original TLS config (CURL_SSLVERSION_TLSv1_2 is only a *minimum*,
 *     TLS 1.3 is still negotiated);
 * 1 = min and max both pinned to TLS 1.2 control group. */
extern int g_forceTls12;

DT_UP_RET curlDownloadFile(const char *url, const char *pFilePath, int *pFileSize);

#endif /* NETWORKUTILS_H */
