#!/bin/bash
#
# Repeatedly run one sample binary and summarize the results.
#
#   ./run_loop.sh <binary> <iterations> [--tls12]
#
# Writes a per-iteration log under logs/ and prints a summary.  A run is
# considered OK when the process exits 0 and the sample reports "download ok".
#
# Example:
#   ./run_loop.sh build/plain/curl_download_orig 20
#   ./run_loop.sh build/plain/curl_download_orig 20 --tls12

set -u

BIN="${1:?usage: run_loop.sh <binary> <iterations> [--tls12]}"
N="${2:?usage: run_loop.sh <binary> <iterations> [--tls12]}"
EXTRA="${3:-}"

case "$BIN" in
    /*) ;;
    *) BIN="$(cd "$(dirname "$BIN")" && pwd)/$(basename "$BIN")" ;;
esac

[ -x "$BIN" ] || { echo "not executable: $BIN" >&2; exit 2; }

mkdir -p logs
STAMP="$(date +%Y%m%d-%H%M%S)"
TAG="$(basename "$(dirname "$BIN")")-$(basename "$BIN")"
[ "$EXTRA" = "--tls12" ] && TAG="${TAG}-tls12"
LOG="logs/${STAMP}-${TAG}.log"

ok=0
fail=0
crash=0

for i in $(seq 1 "$N"); do
    out="$("$BIN" $EXTRA 2>&1)"
    rc=$?
    line="run=$i exit=$rc"
    if [ "$rc" -eq 0 ] && printf '%s' "$out" | grep -q "download ok"; then
        ok=$((ok + 1))
        line="$line result=ok"
    else
        fail=$((fail + 1))
        line="$line result=fail"
    fi
    # signal exits commonly used by crashes (SIGSEGV=139, SIGABRT=134, ...)
    if [ "$rc" -ge 128 ]; then
        crash=$((crash + 1))
        line="$line result=crash"
    fi
    printf '%s\n' "$line" >> "$LOG"
    printf '%s\n' "$out" | sed 's/^/  | /' >> "$LOG"
    printf '%s\n' "" >> "$LOG"
done

echo "binary:  $BIN"
echo "log:     $LOG"
echo "summary: $ok ok, $fail failed ($crash crashed) of $N runs"
