#!/bin/bash
#
# Reproducible build for the curl/OpenSSL coredump investigation.
#
#   ./build.sh            # download + verify + build deps + build samples
#   ./build.sh deps       # download + verify + build OpenSSL/curl (plain+asan)
#   ./build.sh samples    # compile the 4 sample executables
#   ./build.sh checksums  # print the verified checksums
#
# Versions follow the official sources:
#   OpenSSL 3.5.7 -> https://github.com/openssl/openssl/releases/tag/openssl-3.5.7
#                    (the link published on https://www.openssl-library.org/source/)
#   curl    8.20.0 -> https://curl.se/download/curl-8.20.0.tar.gz
#
# Integrity:
#   OpenSSL tarball is verified against the SHA-256 published on the official
#   GitHub release page.  curl publishes no SHA-256 file, so the recorded
#   hash was cross-checked by downloading the identical asset from curl.se and
#   from the official curl GitHub release and comparing the digests.
#
# Everything stays under deps/ and build/; no system libraries are installed.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
DEPS="$ROOT/deps"
BUILD="$ROOT/build"
JOBS="${JOBS:-$(sysctl -n hw.ncpu 2>/dev/null || echo 4)}"

OPENSSL_VER="3.5.7"
CURL_VER="8.20.0"
OPENSSL_SHA256="a8c0d28a529ca480f9f36cf5792e2cd21984552a3c8e4aa11a24aa31aeac98e8"
CURL_SHA256="fc5819cad3f9f5482669adcdc49a782c15f36d2a0715b395b06d9173593d2dc0"

OPENSSL_URL="https://github.com/openssl/openssl/releases/download/openssl-${OPENSSL_VER}/openssl-${OPENSSL_VER}.tar.gz"
CURL_URL="https://curl.se/download/curl-${CURL_VER}.tar.gz"

OPENSSL_SRC="$DEPS/openssl-$OPENSSL_VER-src"
CURL_SRC="$DEPS/curl-$CURL_VER-src"
OPENSSL_BUILD_PLAIN="$DEPS/openssl-$OPENSSL_VER-build-plain"
OPENSSL_BUILD_ASAN="$DEPS/openssl-$OPENSSL_VER-build-asan"
CURL_BUILD_PLAIN="$DEPS/curl-$CURL_VER-build-plain"
CURL_BUILD_ASAN="$DEPS/curl-$CURL_VER-build-asan"

OPENSSL_PREFIX="$DEPS/openssl-$OPENSSL_VER-install"
CURL_PREFIX="$DEPS/curl-$CURL_VER-install"
OPENSSL_ASAN_PREFIX="$DEPS/openssl-$OPENSSL_VER-asan-install"
CURL_ASAN_PREFIX="$DEPS/curl-$CURL_VER-asan-install"

log() { printf '[build] %s\n' "$*"; }
die() { printf '[build] ERROR: %s\n' "$*" >&2; exit 1; }

verify_sha256() {
    local file="$1" expected="$2"
    local actual
    actual="$(shasum -a 256 "$file" | awk '{print $1}')"
    if [ "$actual" != "$expected" ]; then
        die "checksum mismatch for $file: got $actual expected $expected"
    fi
    log "checksum ok: $(basename "$file") $actual"
}

fetch() {
    mkdir -p "$DEPS"
    if [ ! -f "$DEPS/openssl-$OPENSSL_VER.tar.gz" ]; then
        log "downloading OpenSSL $OPENSSL_VER"
        curl -fsSL --retry 3 --max-time 600 -o "$DEPS/openssl-$OPENSSL_VER.tar.gz" "$OPENSSL_URL"
    fi
    verify_sha256 "$DEPS/openssl-$OPENSSL_VER.tar.gz" "$OPENSSL_SHA256"

    if [ ! -f "$DEPS/curl-$CURL_VER.tar.gz" ]; then
        log "downloading curl $CURL_VER"
        curl -fsSL --retry 3 --max-time 300 -o "$DEPS/curl-$CURL_VER.tar.gz" "$CURL_URL"
    fi
    verify_sha256 "$DEPS/curl-$CURL_VER.tar.gz" "$CURL_SHA256"
}

extract() {
    local archive="$1" dir="$2"
    if [ ! -d "$dir" ]; then
        log "extracting $(basename "$archive")"
        tar -xzf "$archive" -C "$DEPS"
        mv "$DEPS/$(basename "$archive" .tar.gz)" "$dir"
    fi
}

build_openssl() {
    local flavor="$1" prefix="$2" build_dir="$3" extra_flags="$4"
    local src="$OPENSSL_SRC"

    extract "$DEPS/openssl-$OPENSSL_VER.tar.gz" "$src"
    mkdir -p "$build_dir"
    cd "$build_dir"
    if [ ! -f Makefile ]; then
        log "configuring OpenSSL $OPENSSL_VER ($flavor)"
        "$src/Configure" darwin64-arm64-cc no-shared no-tests \
            --prefix="$prefix" --openssldir="$prefix/ssl" \
            -g -O0 -fno-omit-frame-pointer $extra_flags
    fi
    if [ ! -f "$prefix/lib/libssl.a" ] || [ ! -f "$prefix/lib/libcrypto.a" ]; then
        log "building OpenSSL $OPENSSL_VER ($flavor)"
        make -j"$JOBS" build_libs || die "OpenSSL build failed ($flavor)"
        make install_sw || die "OpenSSL install failed ($flavor)"
    else
        log "OpenSSL $OPENSSL_VER ($flavor) already built"
    fi
}

build_curl() {
    local flavor="$1" openssl_prefix="$2" prefix="$3" \
          build_dir="$4" cflags="$5" ldflags="$6"
    local src="$CURL_SRC"

    extract "$DEPS/curl-$CURL_VER.tar.gz" "$src"
    mkdir -p "$build_dir"
    cd "$build_dir"
    if [ ! -f Makefile ]; then
        log "configuring curl $CURL_VER ($flavor)"
        env CFLAGS="$cflags" LDFLAGS="$ldflags" \
            "$src/configure" \
            --disable-shared --enable-static \
            --with-openssl="$openssl_prefix" \
            --with-ca-bundle=/etc/ssl/cert.pem \
            --prefix="$prefix" \
            --disable-ldap --disable-ldaps --disable-rtsp \
            --disable-dict --disable-telnet --disable-tftp \
            --disable-pop3 --disable-imap --disable-smtp \
            --disable-gopher --disable-mqtt \
            --disable-ftp --disable-file \
            --disable-manual --disable-docs --disable-alt-svc --disable-hsts \
            --disable-ares \
            --without-libpsl --without-libidn2 --without-brotli --without-zstd \
            --without-zlib --without-nghttp2 --without-ngtcp2 --without-nghttp3 \
            --without-quiche --without-librtmp --without-libssh2 \
            --without-libgsasl --without-gssapi --without-kerberos \
            --without-secure-transport --without-schannel --without-amissl \
            --without-wolfssl --without-mbedtls --without-bearssl \
            --without-rustls --without-gnutls --without-nss \
            --enable-debug
    fi
    if [ ! -f "$prefix/lib/libcurl.a" ]; then
        log "building curl $CURL_VER ($flavor)"
        make -j"$JOBS" || die "curl build failed ($flavor)"
        make install || die "curl install failed ($flavor)"
    else
        log "curl $CURL_VER ($flavor) already built"
    fi
}

build_samples() {
    local flavor="$1" curl_prefix="$2" openssl_prefix="$3" san_flags="$4"
    local out="$BUILD/$flavor"
    local os_frameworks="-framework SystemConfiguration -framework CoreFoundation"

    mkdir -p "$out"
    log "building samples ($flavor)"
    cc -g -O0 -Wall -Wextra -fno-omit-frame-pointer $san_flags \
        -I"$curl_prefix/include" -I"$openssl_prefix/include" \
        -DNO_GLOBAL_CLEANUP \
        "$ROOT/main.c" "$ROOT/networkUtils.c" \
        "$curl_prefix/lib/libcurl.a" "$openssl_prefix/lib/libssl.a" \
        "$openssl_prefix/lib/libcrypto.a" \
        $os_frameworks \
        -o "$out/curl_download_orig"

    cc -g -O0 -Wall -Wextra -fno-omit-frame-pointer $san_flags \
        -I"$curl_prefix/include" -I"$openssl_prefix/include" \
        "$ROOT/main.c" "$ROOT/networkUtils_fixed.c" \
        "$curl_prefix/lib/libcurl.a" "$openssl_prefix/lib/libssl.a" \
        "$openssl_prefix/lib/libcrypto.a" \
        $os_frameworks \
        -o "$out/curl_download_fixed"
    log "samples ready under $out"
}

cmd_deps() {
    fetch
    build_openssl plain "$OPENSSL_PREFIX" "$OPENSSL_BUILD_PLAIN" ""
    build_openssl asan "$OPENSSL_ASAN_PREFIX" "$OPENSSL_BUILD_ASAN" \
        "-fsanitize=address,undefined"
    build_curl plain "$OPENSSL_PREFIX" "$CURL_PREFIX" "$CURL_BUILD_PLAIN" \
        "-g -O0 -fno-omit-frame-pointer" ""
    build_curl asan "$OPENSSL_ASAN_PREFIX" "$CURL_ASAN_PREFIX" "$CURL_BUILD_ASAN" \
        "-g -O0 -fno-omit-frame-pointer -fsanitize=address,undefined" \
        "-fsanitize=address,undefined"
}

cmd_samples() {
    [ -d "$CURL_PREFIX" ] || die "deps missing, run ./build.sh deps first"
    [ -d "$CURL_ASAN_PREFIX" ] || die "asan deps missing, run ./build.sh deps first"
    build_samples plain "$CURL_PREFIX" "$OPENSSL_PREFIX" ""
    build_samples asan "$CURL_ASAN_PREFIX" "$OPENSSL_ASAN_PREFIX" "-fsanitize=address,undefined"
}

cmd_checksums() {
    echo "openssl-${OPENSSL_VER}.tar.gz  $OPENSSL_SHA256  (official GitHub release sha256)"
    echo "curl-${CURL_VER}.tar.gz       $CURL_SHA256  (curl.se == github.com/curl/curl mirrors)"
}

case "${1:-all}" in
    deps)      cmd_deps ;;
    samples)   cmd_samples ;;
    checksums) cmd_checksums ;;
    all)       cmd_deps; cmd_samples ;;
    *)         die "usage: $0 [deps|samples|checksums|all]" ;;
esac
