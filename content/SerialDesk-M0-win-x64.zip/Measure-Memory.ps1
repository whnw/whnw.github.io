param(
    [string]$Exe = "$PSScriptRoot\app\SerialDesk.exe",
    [int]$Runs = 5,
    [int]$IdleSeconds = 300,
    [string]$OutputDirectory = "$PSScriptRoot\results"
)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
if (-not ('NativeMemory' -as [type])) { Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class NativeMemory {
    [StructLayout(LayoutKind.Sequential)] public struct Counters {
        public uint cb, PageFaultCount;
        public UIntPtr PeakWorkingSetSize, WorkingSetSize, QuotaPeakPagedPoolUsage, QuotaPagedPoolUsage;
        public UIntPtr QuotaPeakNonPagedPoolUsage, QuotaNonPagedPoolUsage, PagefileUsage, PeakPagefileUsage, PrivateUsage;
    }
    [DllImport("psapi.dll", SetLastError=true)] public static extern bool GetProcessMemoryInfo(IntPtr process, out Counters counters, uint size);
    [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hwnd);
}
'@
}
$results = @()
for ($run = 1; $run -le $Runs; $run++) {
    if (Get-Process SerialDesk -ErrorAction SilentlyContinue) { throw 'Close the existing SerialDesk process before measurement.' }
    $process = Start-Process -FilePath $Exe -PassThru
    $started = [DateTime]::UtcNow
    $visibleAt = $null
    $rows = [System.Collections.Generic.List[object]]::new()
    $max = @{ WorkingSetSize = 0L; PrivateUsage = 0L; PeakWorkingSetSize = 0L; PeakPagefileUsage = 0L }
    $listenerSeen = $false
    try {
        while ($true) {
            $process.Refresh()
            if ($process.HasExited) { throw "SerialDesk exited: $($process.ExitCode)" }
            $now = [DateTime]::UtcNow
            $counters = [NativeMemory+Counters]::new()
            $size = [Runtime.InteropServices.Marshal]::SizeOf($counters)
            $counters.cb = $size
            if (-not [NativeMemory]::GetProcessMemoryInfo($process.Handle, [ref]$counters, $size)) { throw 'GetProcessMemoryInfo failed' }
            $row = [ordered]@{ elapsedMs = [int]($now - $started).TotalMilliseconds }
            foreach ($key in @('WorkingSetSize','PrivateUsage','PeakWorkingSetSize','PeakPagefileUsage')) {
                $value = [long]$counters.$key.ToUInt64(); $row[$key] = $value
                if ($value -gt $max[$key]) { $max[$key] = $value }
            }
            $rows.Add([pscustomobject]$row)
            if ($process.MainWindowHandle -ne [IntPtr]::Zero -and -not $visibleAt) { $visibleAt = $now }
            if (-not $visibleAt -and ($now - $started).TotalSeconds -gt 180) { throw 'Main window did not appear within 180 seconds.' }
            if ($visibleAt -and ($now - $visibleAt).TotalSeconds -ge $IdleSeconds) { break }
            Start-Sleep -Milliseconds 100
        }
        $listeners = @(Get-NetTCPConnection -State Listen -LocalPort 8765 -ErrorAction SilentlyContinue | Where-Object OwningProcess -eq $process.Id)
        $listenerSeen = @($listeners | Where-Object LocalAddress -eq '0.0.0.0').Count -gt 0
        if (-not $listenerSeen) { throw 'MCP is not listening on 0.0.0.0:8765 in the GUI process.' }
        if (-not [NativeMemory]::IsWindowVisible($process.MainWindowHandle) -or [NativeMemory]::IsIconic($process.MainWindowHandle)) { throw 'Main window must remain visible and not minimized.' }
        $rows | Export-Csv "$OutputDirectory\memory-run-$run.csv" -NoTypeInformation
        $results += [pscustomobject]@{ run = $run; idleSeconds = $IdleSeconds; samples = $rows.Count; dpi = [NativeMemory]::GetDpiForWindow($process.MainWindowHandle); maxima = $max; ipv4Listener = $listenerSeen; listeners = @($listeners | Select-Object LocalAddress,LocalPort,OwningProcess); memoryPassed = @($max.Values | Where-Object { $_ -gt 50000000 }).Count -eq 0 }
        $results | ConvertTo-Json -Depth 6 | Set-Content "$OutputDirectory\memory-summary.json"
    } finally {
        if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
        $process.Dispose()
    }
}
$os = Get-CimInstance Win32_OperatingSystem
Add-Type -AssemblyName System.Windows.Forms
$display = [Windows.Forms.Screen]::PrimaryScreen.Bounds
$meta = @{ os = $os.Caption; version = $os.Version; build = $os.BuildNumber; architecture = $os.OSArchitecture; resolution = "$($display.Width)x$($display.Height)"; processArchitecture = $env:PROCESSOR_ARCHITECTURE; runs = $Runs; idleSeconds = $IdleSeconds; rebootFirstRunVerified = $false; acceptanceComplete = $false; note = 'Requires a separately documented post-reboot run, DPI record, and all maxima <= 50,000,000 bytes.' }
$meta | ConvertTo-Json | Set-Content "$OutputDirectory\environment.json"
$results | ConvertTo-Json -Depth 6
