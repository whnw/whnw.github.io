param([int]$ProcessId, [string]$TokenFile, [string]$OutputDirectory = "$PSScriptRoot\results")
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$condition = [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty, $ProcessId)
$window = [Windows.Automation.AutomationElement]::RootElement.FindFirst([Windows.Automation.TreeScope]::Children, $condition)
if (-not $window) { throw 'GUI window not found for serial smoke test.' }
function Find-Control([string]$automationId) {
    $match = [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::AutomationIdProperty, $automationId)
    $element = $window.FindFirst([Windows.Automation.TreeScope]::Descendants, $match)
    if (-not $element) { throw "Control not found: $automationId" }
    return $element
}
$port = Find-Control 'portSelector'
$port.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).SetValue('COM1')
(Find-Control 'connectButton').GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern).Invoke()
Start-Sleep -Seconds 2
(Find-Control 'sendText').GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).SetValue('help')
(Find-Control 'sendButton').GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern).Invoke()
Start-Sleep -Seconds 3
& "$PSScriptRoot\probe\SerialDesk.McpProbe.exe" 'http://127.0.0.1:8765/mcp' $TokenFile '--serial' | Out-File "$OutputDirectory\serial-smoke.json" -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw "Virtual COM1 smoke failed: $LASTEXITCODE" }
