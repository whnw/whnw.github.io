param([int]$Runs = 1, [int]$IdleSeconds = 30)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$results = "$root\results"
$runId = [Guid]::NewGuid().ToString('N')
if (Test-Path $results) {
    New-Item -ItemType Directory -Force "$root\history" | Out-Null
    Move-Item $results "$root\history\$runId"
}
New-Item -ItemType Directory -Force $results | Out-Null
$principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
$state = [ordered]@{
    runId = $runId; startedAtUtc = [DateTime]::UtcNow.ToString('o'); phase = 'starting'; suiteCompleted = $false
    elevated = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    appAssemblySha256 = (Get-FileHash "$root\app\SerialDesk.dll" -Algorithm SHA256).Hash
    runs = $Runs; idleSeconds = $IdleSeconds; error = $null
}
function Save-State {
    $text = $state | ConvertTo-Json -Depth 6
    [IO.File]::WriteAllText("$results\run-state.json", $text)
}
Save-State
Start-Transcript "$results\lab.log" -Force
try {
    $tokenBytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($tokenBytes); $rng.Dispose()
    $token = [BitConverter]::ToString($tokenBytes).Replace('-', '')
    $sha = [Security.Cryptography.SHA256]::Create()
    $digest = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($token))).Replace('-', ''); $sha.Dispose()
    $credentials = "$env:APPDATA\SerialDesk"; New-Item -ItemType Directory -Force $credentials | Out-Null
    @{schemaVersion=1; principalId='m0-reader'; scope='read'; sha256=$digest} | ConvertTo-Json | Set-Content "$credentials\credentials.json"
    $tokenFile = "$root\lab-token.txt"; [IO.File]::WriteAllText($tokenFile, $token)
    & "$root\Measure-Memory.ps1" -Runs $Runs -IdleSeconds $IdleSeconds -OutputDirectory $results | Out-File "$results\memory-output.json"
    $state.phase = 'memory-complete'; Save-State
    $app = Start-Process "$root\app\SerialDesk.exe" -PassThru
    try {
        $ready = $false
        for ($i=0; $i -lt 180; $i++) {
            try { $null = Invoke-RestMethod 'http://127.0.0.1:8765/healthz' -TimeoutSec 2; $ready = $true; break } catch { Start-Sleep -Seconds 1 }
        }
        if (-not $ready) { throw 'Health check failed.' }
        & "$root\probe\SerialDesk.McpProbe.exe" 'http://127.0.0.1:8765/mcp' $tokenFile | Out-File "$results\mcp-probe.json" -Encoding utf8
        if ($LASTEXITCODE -ne 0) { throw "Official SDK probe failed: $LASTEXITCODE" }
        $state.phase = 'mcp-complete'; Save-State
        $memory = [NativeMemory+Counters]::new()
        $size = [Runtime.InteropServices.Marshal]::SizeOf($memory)
        $memory.cb = $size
        if (-not [NativeMemory]::GetProcessMemoryInfo($app.Handle, [ref]$memory, $size)) { throw 'Post-MCP memory snapshot failed' }
        @{ WorkingSetSize = $memory.WorkingSetSize.ToUInt64(); PrivateUsage = $memory.PrivateUsage.ToUInt64(); PeakWorkingSetSize = $memory.PeakWorkingSetSize.ToUInt64(); PeakPagefileUsage = $memory.PeakPagefileUsage.ToUInt64() } | ConvertTo-Json | Set-Content "$results\post-mcp-memory.json"
        & "$root\Run-SerialSmoke.ps1" -ProcessId $app.Id -TokenFile $tokenFile -OutputDirectory $results
        $state.phase = 'serial-complete'; Save-State
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $bounds = [Windows.Forms.Screen]::PrimaryScreen.Bounds
        $image = New-Object Drawing.Bitmap $bounds.Width,$bounds.Height
        $graphics = [Drawing.Graphics]::FromImage($image); $graphics.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size)
        $image.Save("$results\desktop.png", [Drawing.Imaging.ImageFormat]::Png); $graphics.Dispose(); $image.Dispose()
    } finally { if (-not $app.HasExited) { Stop-Process -Id $app.Id -Force }; Remove-Item $tokenFile -ErrorAction SilentlyContinue }
    'finished' | Set-Content "$results\status.txt"
    $state.phase = 'finished'; $state.suiteCompleted = $true
} catch { $state.phase = 'failed'; $state.error = $_.Exception.Message; $_ | Out-String | Set-Content "$results\error.txt"; throw }
finally { Save-State; Stop-Transcript }
