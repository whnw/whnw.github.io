# Windows 版首版验收报告

2026-11-04，SerialWin 1.0.0，Windows 11 x64。已完成先设计、后编码、核心检查、Win11 实际运行及交付文件验证。

## 交付

- 独立 WinForms 工程：`windows/SerialWin.slnx`。
- 自包含单文件：`windows/artifacts/win-x64/SerialWin.exe`，64,522,506 字节（约 61.5 MiB）。无需预装 .NET，普通账户直接运行；未签名。
- Win11 测试账户桌面已放置 `SerialWin.exe` 副本，可双击以日常模式运行。
- 完整交付包：`windows/artifacts/SerialWin-1.0.0-win11-x64.zip`，包含同一 EXE、说明、设计、截图、许可证及本轮 JSON 结果。
- 设计：[Windows 版设计文档](Windows版设计文档.md)；操作和构建：[Windows README](../windows/README.md)。

本轮 EXE 的 SHA-256：

```text
cc6b21763ef30131000a5c9ecfcdb0d29f16f544f31d2ab679e353c61a6d27ae
```

Win11 自动报告及 MCP 报告均记录该散列，打包脚本要求两份报告通过且与当前 EXE 一致。

## 验证结果

| 检查 | 结果 | 范围 |
| --- | --- | --- |
| Release 构建与自包含发布 | 通过，0 警告 / 0 错误 | WinForms、Core、MCP SDK、win-x64 单文件 |
| Core 可执行检查 | 28 项通过 | Unicode 分批、短写/取消/队列上限、独立游标/gap、定时收集、宏分类录制/JSON、日志并发追加、高亮、VT 屏幕 |
| Win11 自动回归 | 16 项通过 | 原生窗口/五个菜单、配置/设置/宏编辑窗、发送栏、COM1 收发、中文宏、录制、忙状态、停止、重连、日志 |
| HTTP MCP 联调 | 19 项通过 | 8 工具、初始化、两客户端、精确字节、Base64/中文、发送进度、时窗/字节上限、旧编号、端口复用、HTTP 方法/Origin |
| 服务停止与恢复 | 通过 | 600 秒读取主动结束，返回 server_stopped；恢复后仍为原串口 connectionID |

Windows 报告 API 返回 `Microsoft Windows NT 10.0.26300.0`，进程架构 `X64`。使用现有 `mobaxterm-serial` QEMU x64 测试机和实际 QEMU COM1，宿主通过 TCP 18766 模拟设备、18767 转发访问 Windows 内的 8765。串口夹具复用了 macOS 相同的 PING、ECHO、ifconfig、SAMPLE 等命令实现。MCP 服务端使用官方 C# SDK 2.3.0，协议客户端使用 Python HTTP/JSON，验证初始化版本 2025-03-26。

自动运行时间：2026-11-04T08:36:59.4574719+08:00 至 2026-11-04T08:37:34.0412289+08:00。服务停止检查在注册 600 秒窗口后手动点击面板停止，实际约 31.0 秒结束；不是持续十分钟或更长时间的性能测试。

主要行为已验证：

- 真实 COM1 PING/PONG；UTF-8 中文通过宏和 MCP Base64 往返；TX 进度查询不导致重发。
- 连续文本跨停顿合并为一个宏文本步骤；按键单独保存；执行期间拒绝目标连接写入；停止取消尚未执行的延迟步骤。
- 断开时 Windows SerialStream 的预期读取取消异常正常收尾；按设备路径重开复用原标签，生成新 connectionID，旧编号不能写入新连接。
- 日志含带时间戳的 RX 和 `[TX]` 命令，中文正确、无 ANSI；同标签重连保持文件。Core 另验证同名同秒双写入器追加 60 行不覆盖。
- MCP 后台初始化期间界面可以绘制和操作；面板停止保留串口，等待中的读取正常返回，随后可恢复服务。

证据文件位于 `windows/artifacts/`：`smoke-report.json`、`mcp-report.json`、`service-stop-report.json`、`com-received.jsonl`、`SHA256SUMS.txt`。发布 ZIP 只携带最终通过的报告。之前的失败检查用于修复回归问题，不作为本版通过证据。

## 界面

主窗口（Windows 内生成）：

![SerialWin 主窗口](images/windows/main.png)

会话配置：

![串口会话配置](images/windows/session.png)

应用设置：

![应用设置](images/windows/settings.png)

宏编辑：

![宏编辑](images/windows/macro.png)

## 验证边界

- QEMU COM1 不是实体 USB 适配器；真实波特率、7 位/校验/线路流控、USB 拔插和长时吞吐仍需实机验证。发送调度器的部分写入检查基于模拟短写，未验证真实 Windows 驱动写超时时的部分字节进度。
- 终端实现常用串口 shell 的 UTF-8/ANSI/VT 操作，不宣称完整 SwiftTerm/xterm 兼容；复杂全屏程序、多 DPI、IME 交互和睡眠恢复未全面验收。
- 本轮未验证所有 MCP 协议版本、所有客户端或外部物理局域网机器；宿主访问使用 QEMU 转发。应用按 Mac 当前行为监听全部 IPv4 地址、无认证，不自行更改防火墙；测试机通过 Windows 的应用网络访问提示放行。
- 与当前 Mac 已实现范围对应，本版未增加搜索、DTR/RTS/Break、日志暂停等尚未交付的功能。

## 复现

```sh
cd windows
# 有 .NET 10.0.403 SDK 的开发机
./scripts/publish.sh
# 在 Win11 中运行 SerialWin.exe --smoke；独立使用 SerialWinLab 配置目录
# 宿主在 COM1 夹具运行且 Windows 网络访问放行后执行
python3 scripts/check-mcp.py --url http://127.0.0.1:18767/mcp
# 根据终端提示，在应用面板停止/启动服务
python3 scripts/check-service-stop.py --url http://127.0.0.1:18767/mcp
# 报告和散列一致后生成交付包
python3 scripts/write-report.py
python3 scripts/package.py
```

`--smoke` 的配置和日志位于 `%LOCALAPPDATA%\SerialWinLab`，日常双击运行使用 `%LOCALAPPDATA%\SerialWin`。首次单文件运行会解包内置运行库；本轮 TCG 虚拟机速度不能用作真实 x64 设备性能结论。
