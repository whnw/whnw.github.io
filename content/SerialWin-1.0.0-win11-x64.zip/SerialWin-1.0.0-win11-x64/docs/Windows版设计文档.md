# SerialWin Windows 11 设计与验收

版本 1.0，2026-11-03。依据当前 SerialMac 源码和《串口应用设计文档》v0.23，移植已实现功能；本文件先于 Windows 编码建立。macOS 源码与已有未提交变更保持原样。

## 交付和技术选择

新增 `windows/` 独立 C# 工程：.NET 10、WinForms、System.IO.Ports、官方 MCP C# SDK。Win11 x64 为验收目标。发布自包含单文件 `SerialWin.exe`，普通账户直接双击运行，无需预装 .NET。按用户要求 exe 或 MSI 二选一，本版交付 exe。未持有代码签名证书，产物不签名。

核心与 UI 分离：Core 负责配置、字节缓冲、节流写入、宏、日志和终端状态；App 负责 WinForms、真实 COM 传输和 MCP；Checks 提供确定时钟及模拟传输测试。Windows 原型仅复用 SDK/VM 工具，不受其历史 M0 内存门槛约束。

## UI 与操作映射

主窗默认 1280×800，最小 960×640，Per-Monitor V2 DPI。

- 菜单：文件（新建会话 Ctrl+N、退出）、会话（连接、断开、重连、设置、关闭标签 Ctrl+W）、宏（新建、录制、停止、恢复草稿）、视图（会话/宏/MCP 侧栏、发送栏）、应用设置 Ctrl+,。
- 工具栏：新建会话、宏；录制/运行期间才显示停止；右侧发送栏、应用设置。宏左击切换列表，右击新建/录制。
- 左侧三入口：会话、宏、MCP。会话/宏单击选中，双击连接/执行；列表右键提供操作。会话状态同步标签；标签右键连接/断开/重连/设置，叉号直接关闭。
- 空工作区显示新建提示；连接终端采用深色等宽文本，支持 UTF-8 分块、ANSI SGR、光标移动/定位、擦除、滚动区、备用屏幕、控制键、粘贴和鼠标文本选择复制。OSC 不访问主机剪贴板。
- 可折叠发送栏：单行文本、CR/LF/CRLF/None、回显、最多 100 条去重历史、发送、关闭。状态栏显示连接状态、累计 RX/TX、UTF-8/波特率、可点击日志及错误。
- 会话配置：名称、COM 端口（每秒枚举并可手输）、六档 9600–230400、7/8 数据位、None/Even/Odd、1/2 停止位、None/XON-XOFF/RTS-CTS、本地回显、高亮、日志目录。Windows 无 PTY 选项。保存新会话立即连接；仅改名称/目录不重连，活动串口参数变更保存并重连。目录下次开标签生效。
- 应用设置：发送节流和文本高亮。七种固定颜色及内置规则与 Mac 一致；自定义词字面包含、不区分大小写、跨类别去重，最多 500 词，每词 1–128 字符，立即保存刷新。

## 串口、生命周期与数据

每个连接独立串行发送器；默认每 20ms 最多 20 个 Unicode 码点，原始 Base64 按字节分批。每连接队列 1MiB，迟到不补发。TX 只在系统写入成功后累加，失败不自动重发。断开取消未发数据，重连新 connectionID；读取旧连接历史，写入旧编号拒绝。UI 显示轮询有界缓冲，避免无界 UI 投递。COM 独占打开，重复相同配置复用，不一致返回冲突。设备错误结束连接并保留终端。

配置位于 `%LOCALAPPDATA%\SerialWin`，JSON 临时文件原子替换；坏文件备份并显示错误。日志默认 `%USERPROFILE%\Documents\SerialWin`。标签创建即打开 `会话名_yyyy-MM-dd_HH-mm-ss.log`，同名同秒追加；同标签重连同文件。RX 分块 UTF-8、ANSI/OSC 过滤、逐行时间戳、CR/LF/CRLF 归一；成功 TX 聚合 `[TX]` 命令，支持退格、Ctrl+C、断开刷新。日志后台队列有界 16MiB，错误独立展示，不终止串口。

宏采用文本、按键、delay 三类步骤，支持新建/编辑/复制/删除、上下移、去延时。录制仅捕获当前连接成功的 UI TX，文本内部停顿不拆分，完整按键后等待 ≥40ms 才插 delay；UTF-8/按键跨块保留；最多 1MiB，草稿持久化可恢复。回放绑定启动连接，每连接一个宏，期间 UI/MCP 写入返回忙，读取正常。停止按钮结束录制并打开草稿，同时取消全部宏及其排队数据。断开保留草稿，取消执行。

## MCP

启动自动监听 `0.0.0.0:8765/mcp`，与 Mac 保持无认证行为；面板显示地址/状态、复制、启停，端口占用仅报错不影响串口。浏览器 Origin 拒绝，HTTP 请求体 1MiB、连接并发有界。不自动修改防火墙。

工具名称与参数沿用 Mac：`serial_list_ports`、`serial_list_sessions`、`serial_open`、`serial_read`、`serial_read_for`、`serial_write`、`serial_write_status`、`serial_close`。sessionID/connectionID 明确定位，RX 环 8MiB、独立非消费 cursor、淘汰返回 gap、Base64 为精确字节。read 支持等到首个数据/超时；read_for 从注册时直接收集、等待完整小数秒时窗、最多 1MiB、byte_limit 提前结束；服务停止/取消/串口关闭结束等待。write 返回 writeID 和实际进度，查询不重发；共用队列、节流及日志。使用官方 SDK 管理协议初始化及会话。

## 验收与边界

先通过跨平台 Core 检查：分块 Unicode/ANSI、节流/队列/取消、RX 游标与 gap、定时窗口、日志文件/命令、宏录制/持久化、高亮；再交叉构建并发布单文件 exe。Win11 QEMU 使用现有 `mobaxterm-serial` 虚拟磁盘，在普通账户运行 exe，检查首窗、菜单/按钮、会话配置、COM1 真实虚拟串口收发、日志、宏、MCP 八工具及重连旧编号隔离，并保存截图/报告及产物散列。

本版不增加 Mac 尚未实现的搜索、DTR/RTS/Break、日志暂停、睡眠恢复，也不宣称完整 xterm 兼容。自研终端覆盖常见串口 shell 的 VT 操作；复杂全屏程序、真实 USB 适配器/拔插、多 DPI 和长时吞吐需目标设备补验。QEMU COM1 验证不等同硬件验收，TCG 速度不作为真实机器性能指标。

技术依据：[Microsoft 单文件发布](https://learn.microsoft.com/en-us/dotnet/core/deploying/single-file/)、[官方 MCP HTTP 传输](https://github.com/modelcontextprotocol/csharp-sdk/blob/main/docs/concepts/transports/transports.md)。
